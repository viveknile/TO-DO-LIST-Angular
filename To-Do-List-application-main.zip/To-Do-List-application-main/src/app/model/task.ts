export class Task {
    id : number = 0;
    task_name : string = '';
}
